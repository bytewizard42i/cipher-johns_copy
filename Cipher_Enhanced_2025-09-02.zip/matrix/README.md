# matrix

[![Package Version](https://img.shields.io/hexpm/v/matrix)](https://hex.pm/packages/matrix)
[![Hex Docs](https://img.shields.io/badge/hex-docs-ffaff3)](https://hexdocs.pm/matrix/)

```sh
gleam add matrix@1
```
```gleam
import matrix

pub fn main() -> Nil {
  // TODO: An example of the project in use
}
```

Further documentation can be found at <https://hexdocs.pm/matrix>.

## Development

```sh
gleam run   # Run the project
gleam test  # Run the tests
```
